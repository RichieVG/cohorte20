package com.generation.jrvg.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolaMundoApplicationTests {

	@Test
	void contextLoads() {
	}

}
